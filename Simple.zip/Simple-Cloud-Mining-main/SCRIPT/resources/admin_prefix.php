<?php
defined('BASEPATH') OR exit('No direct script access allowed');

/*
| -------------------------------------------------------------------------
| Admin route prefix
| -------------------------------------------------------------------------
*/
$config['admin_route_prefix'] = 'ADMIN_PREFIX';
