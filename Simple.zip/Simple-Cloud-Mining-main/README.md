# Simple-Cloud-Mining
Simple Cloud Mining Script with PHP

Tutorial : https://www.youtube.com/watch?v=iitJJ8vYnlk
Demo : https://togwin.com/
Support all coin on coinpayments.net
Donation : DOGE ( DR1G1FTb3sMqbpwBpREkL1uBaaTrdDQukw )

Mail : imskaa.co@gmail.com
