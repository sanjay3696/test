import React from 'react'

export default function Home() {
  return (
    <div>
      <p>Welcome to the Moralis blockchain explorer!</p>
    </div>
  )
}
